clc;
clear all;
Func_num = input('Input the function number: ');
global initial_flag
initial_flag = 0;
func1 = ['Best_Solution\RC' num2str(Func_num) '.txt'];
eval('x=load(func1);');
Par     = Cal_par(Func_num);
D       = Par.n
g       = Par.g
h       = Par.h
xmin    = Par.xmin
xmax    = Par.xmax
Feasible_Solution = x
[f,g,h] = cec20_func(x,Func_num)